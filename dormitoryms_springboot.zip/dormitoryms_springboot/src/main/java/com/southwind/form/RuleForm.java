package com.southwind.form;

import lombok.Data;

@Data
public class RuleForm {
    private String username;
    private String password;
}
