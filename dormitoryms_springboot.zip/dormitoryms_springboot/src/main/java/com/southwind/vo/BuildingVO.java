package com.southwind.vo;

import lombok.Data;

@Data
public class BuildingVO {
    private Integer id;
    private String name;
    private String introduction;
    private String adminName;
}
