package com.southwind.vo;

import lombok.Data;

@Data
public class PageVO {
    private Object data;
    private Long total;
}
